-- Backup SIGADEA PHP
-- Fecha: 2026-05-31 23:01:45

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `dia` enum('Lunes','Martes','Miercoles','Jueves','Viernes','Sabado','Domingo') NOT NULL,
  `hora` tinyint(3) unsigned NOT NULL,
  `ultima_ejecucion` date DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `docente_id` int(10) unsigned DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido_p` varchar(100) NOT NULL,
  `apellido_m` varchar(100) NOT NULL,
  `turno` varchar(20) NOT NULL DEFAULT 'VESPERTINO',
  `grado` varchar(20) NOT NULL,
  `acta` varchar(255) DEFAULT '',
  `certificado` varchar(255) DEFAULT '',
  `comp_domicilio` varchar(255) DEFAULT '',
  `curp` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status_grado` (`grado`),
  KEY `idx_status_nombre` (`nombre`,`apellido_p`,`apellido_m`),
  KEY `idx_status_docente` (`docente_id`),
  CONSTRAINT `fk_status_docente` FOREIGN KEY (`docente_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('1','2','miguel','ramos','hernandez','VESPERTINO','3 - A','uploads/documents/leon_cristobal_cervantes_3_-_A/miguel_ramos_hernandez/ACTA.pdf','','','','2026-05-31 13:52:21',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('2',NULL,'Daniela','Herrera','Portilla','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('3',NULL,'Epifanio','Sagahon','Fuentes','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('4',NULL,'Airam','Aseret','Cuevas','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('5',NULL,'Jesus','Israel','tercero','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('6',NULL,'Salvador','Lara','Rivera','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('7',NULL,'Brandon','Lara','Rivera','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('8',NULL,'Leon','Cristobal','Servantes','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('9',NULL,'Johan','Isacc','Delgado','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('10',NULL,'Pepe','gutierres','Sanchez','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('11',NULL,'Fernando','Aburto','Lara','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('12',NULL,'Miguel Angel','Perez','Perez','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('13',NULL,'Cindy','Medina','Perez','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('14',NULL,'Thelma','Valeriano','Torres','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('15',NULL,'Janeth','Garcia','Quirino','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('16',NULL,'Ernestina','Hernancez','Velazques','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('17',NULL,'Carlos','Duran','Villegas','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('18',NULL,'David','Acosta','Rivera','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('19',NULL,'Leslie','santos','garcia','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);
INSERT INTO `status` (`id`,`docente_id`,`nombre`,`apellido_p`,`apellido_m`,`turno`,`grado`,`acta`,`certificado`,`comp_domicilio`,`curp`,`created_at`,`updated_at`) VALUES ('20',NULL,'Furina','Lara','Segunda','VESPERTINO','3 - A','','','','','2026-05-31 14:55:07',NULL);

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` enum('administrador','usuario') NOT NULL DEFAULT 'usuario',
  `grado` varchar(20) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuarios_usuario` (`usuario`),
  KEY `idx_usuarios_rol` (`rol`),
  KEY `idx_usuarios_grado` (`grado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `usuarios` (`id`,`nombre_completo`,`usuario`,`password_hash`,`rol`,`grado`,`created_at`,`updated_at`) VALUES ('1','Administrador','admin','$2y$10$wD7Gi4pMI20SU8VsNLTskuBQQ9eKVbxf7JL7bgbYnnmGrpHmRl89S','administrador','','2026-05-31 13:48:49',NULL);
INSERT INTO `usuarios` (`id`,`nombre_completo`,`usuario`,`password_hash`,`rol`,`grado`,`created_at`,`updated_at`) VALUES ('2','leon cristobal cervantes','Layon-pc','$2y$10$dmxjy/ePMOMEtc83j3h.G.s9Giokn0/INeCDKM5yfrGklNVRkGX4i','usuario','3 - A','2026-05-31 13:51:05',NULL);
INSERT INTO `usuarios` (`id`,`nombre_completo`,`usuario`,`password_hash`,`rol`,`grado`,`created_at`,`updated_at`) VALUES ('3','HECTOR MIGUEL MARTINEZ ARGUELLES','LIC HECTOR MIGUEL','$2y$10$dD7lB.f2eOUjqclADJn5c.mAJCc2kcu0h7eBixKxMx1m6V8SBfd9m','administrador','','2026-05-31 21:26:08',NULL);

SET FOREIGN_KEY_CHECKS=1;
